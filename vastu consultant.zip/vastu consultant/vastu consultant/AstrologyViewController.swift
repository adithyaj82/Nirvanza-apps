//
//  AstrologyViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class AstrologyViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

   
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }

    @IBAction func whatAstrology(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/whatisastrology.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func Vedic(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/vedicastrology.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func mundane(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/mundaneastrology.html";
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func predictive(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/predictiveastrology.html";
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func child(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/childastrology.html";
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func numerology(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/numerology.html";
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func business(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/businessastrology.html";
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func nadi(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/hinduastrology.html";
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func horo(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesDetailViewController")as! ServicesDetailViewController
        vc.vv = "http://www.ashwintrivedi.com/nadiastrology.html";
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func web(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController")as! WebViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }


}
