//
//  VastuViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class VastuViewController: UIViewController {
    @IBOutlet weak var myWebView: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let url = URL(string: "http://www.ashwintrivedi.com/vastushastra.html")
        myWebView.loadRequest(URLRequest(url: url!))
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    @IBAction func web(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController")as! WebViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
   

}
