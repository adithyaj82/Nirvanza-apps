//
//  ServicesViewController.swift
//  SideMenuTutorial
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        customizeNavBar()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func customizeNavBar() {
        
        
        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 17/255, green: 94/255, blue: 41/255, alpha: 1)
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    @IBAction func astrology(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/astrology-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func numerology(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/numerology-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func horoscope(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/horoscope-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func faceread(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/face-reading-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func kundli(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/kundli-matching-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func palm(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/palm-reading-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    @IBAction func crystal(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/crystal-therapy-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func hypnosis(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/hypnosis-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func pyravastu(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ServicesWebViewController")as! ServicesWebViewController
        vc.vv = "http://vastushastraexperts.com/pyra-vastu-consultancy-in-ahmedabad.html";
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

}
