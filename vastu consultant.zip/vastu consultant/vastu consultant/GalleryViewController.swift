//
//  GalleryViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/2/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class GalleryViewController: UIViewController {
    @IBOutlet weak var myWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = URL(string: "http://www.ashwintrivedi.com/gallery.html")
        myWebView.loadRequest(URLRequest(url: url!))
    }
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    
    
}
