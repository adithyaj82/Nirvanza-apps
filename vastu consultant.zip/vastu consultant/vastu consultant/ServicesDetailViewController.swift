//
//  ServicesDetailViewController.swift
//  vastu consultant
//
//  Created by adithya on 9/3/18.
//  Copyright © 2018 adithya. All rights reserved.
//

import UIKit

class ServicesDetailViewController: UIViewController {
var vv = String()
    @IBOutlet weak var myWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = URL(string: vv)
        myWebView.loadRequest(URLRequest(url: url!))
    }
    @IBAction func back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
        dismiss(animated: true, completion: nil)
    }
    
    
}
