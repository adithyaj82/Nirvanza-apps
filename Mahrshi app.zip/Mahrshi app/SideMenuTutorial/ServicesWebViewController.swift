//
//  ServicesWebViewController.swift
//  SideMenuTutorial
//
//  Created by adithya on 9/6/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class ServicesWebViewController: UIViewController {
    var vv = String()
    @IBOutlet weak var myWebView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        customizeNavBar()

        let url = URL(string: vv)
        myWebView.loadRequest(URLRequest(url: url!))
    }
//    @IBAction func back(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true, completion: nil)
//    }
    
    
    func customizeNavBar() {
        
        
        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 17/255, green: 94/255, blue: 41/255, alpha: 1)
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
}
